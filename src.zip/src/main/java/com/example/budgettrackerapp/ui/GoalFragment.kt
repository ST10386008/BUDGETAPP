package com.example.budgettrackerapp.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class GoalFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_goal, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val minGoalField = view.findViewById<EditText>(R.id.minGoal)
        val maxGoalField = view.findViewById<EditText>(R.id.maxGoal)
        val saveBtn = view.findViewById<Button>(R.id.saveGoalBtn)

        saveBtn.setOnClickListener {
            val minGoal = minGoalField.text.toString().toDoubleOrNull()
            val maxGoal = maxGoalField.text.toString().toDoubleOrNull()

            if (minGoal != null && maxGoal != null) {
                val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
                val ref = FirebaseDatabase.getInstance().getReference("users/$uid/goals")
                ref.child("minGoal").setValue(minGoal)
                ref.child("maxGoal").setValue(maxGoal)
                Toast.makeText(context, "Goals saved!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            }
        }
    }
}