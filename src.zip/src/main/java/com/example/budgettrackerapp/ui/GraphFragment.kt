package com.example.budgettrackerapp.ui

import android.os.Bundle
import android.os.Environment
import android.view.*
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.models.Expense
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.io.File
import java.io.FileWriter

class GraphFragment : Fragment() {

    private lateinit var pieChart: PieChart
    private lateinit var btnExport: Button
    private var categoryMap: Map<String, Double> = emptyMap()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_graph, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        pieChart = view.findViewById(R.id.pieChart)
        btnExport = view.findViewById(R.id.btnExportCsv)

        loadGraphData()

        btnExport.setOnClickListener {
            exportToCsv(categoryMap)
        }
    }

    private fun loadGraphData() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val ref = FirebaseDatabase.getInstance().getReference("users/$uid/expenses")

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val tempMap = mutableMapOf<String, Double>()

                for (child in snapshot.children) {
                    val exp = child.getValue(Expense::class.java)
                    exp?.let {
                        tempMap[it.category] = (tempMap[it.category] ?: 0.0) + it.amount
                    }
                }

                categoryMap = tempMap
                updateChart(categoryMap)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to load data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun updateChart(dataMap: Map<String, Double>) {
        val entries = dataMap.map { PieEntry(it.value.toFloat(), it.key) }

        val dataSet = PieDataSet(entries, "Expenses by Category").apply {
            colors = ColorTemplate.MATERIAL_COLORS.toList()
            sliceSpace = 3f
            selectionShift = 5f
        }

        val pieData = PieData(dataSet).apply {
            setValueTextSize(14f)
        }

        pieChart.apply {
            data = pieData
            description.isEnabled = false
            centerText = "Spending"
            animateY(1000)
            invalidate()
        }
    }

    private fun exportToCsv(data: Map<String, Double>) {
        val fileName = "spending_data.csv"
        val file = File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)

        try {
            FileWriter(file).use { writer ->
                writer.appendLine("Category,Amount")
                data.forEach { (category, amount) ->
                    writer.appendLine("$category,$amount")
                }
            }
            Toast.makeText(requireContext(), "CSV saved to Documents folder", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error exporting: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
