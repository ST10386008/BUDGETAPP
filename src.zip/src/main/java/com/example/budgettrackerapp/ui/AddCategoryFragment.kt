package com.example.budgettrackerapp.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.models.Category
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AddCategoryFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_add_category, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val categoryName = view.findViewById<EditText>(R.id.categoryName)
        val saveBtn = view.findViewById<Button>(R.id.saveCategoryBtn)

        saveBtn.setOnClickListener {
            val name = categoryName.text.toString()
            if (name.isNotEmpty()) {
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                val ref = FirebaseDatabase.getInstance().getReference("users/$uid/categories")
                val key = ref.push().key ?: return@setOnClickListener
                val category = Category(id = key, name = name)
                ref.child(key).setValue(category)
                Toast.makeText(context, "Category saved!", Toast.LENGTH_SHORT).show()
                categoryName.text.clear()
            } else {
                Toast.makeText(context, "Enter category name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}