package com.example.budgettrackerapp.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.models.Expense
import com.example.budgettrackerapp.utils.BadgeManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.util.*

class AddExpenseFragment : Fragment() {

    private var photoUri: Uri? = null
    private val PICK_IMAGE = 100

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_add_expense, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val date = view.findViewById<EditText>(R.id.expenseDate)
        val start = view.findViewById<EditText>(R.id.expenseStartTime)
        val end = view.findViewById<EditText>(R.id.expenseEndTime)
        val desc = view.findViewById<EditText>(R.id.expenseDesc)
        val category = view.findViewById<EditText>(R.id.expenseCategory)
        val amount = view.findViewById<EditText>(R.id.expenseAmount)
        val addPhoto = view.findViewById<Button>(R.id.addPhotoBtn)
        val saveBtn = view.findViewById<Button>(R.id.saveExpenseBtn)

        addPhoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply {
                type = "image/*"
            }
            startActivityForResult(intent, PICK_IMAGE)
        }

        saveBtn.setOnClickListener {
            val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
            val ref = FirebaseDatabase.getInstance().getReference("users/$uid/expenses")
            val key = ref.push().key ?: return@setOnClickListener

            val expense = Expense(
                id = key,
                date = date.text.toString(),
                startTime = start.text.toString(),
                endTime = end.text.toString(),
                description = desc.text.toString(),
                category = category.text.toString(),
                amount = amount.text.toString().toDoubleOrNull() ?: 0.0
            )

            if (photoUri != null) {
                val storageRef = FirebaseStorage.getInstance().getReference("users/$uid/expense_photos/$key.jpg")
                storageRef.putFile(photoUri!!)
                    .addOnSuccessListener {
                        storageRef.downloadUrl.addOnSuccessListener { uri ->
                            expense.photoUrl = uri.toString()
                            ref.child(key).setValue(expense)
                                .addOnSuccessListener {
                                    Toast.makeText(context, "Expense saved with photo!", Toast.LENGTH_SHORT).show()
                                    BadgeManager.checkAndAwardBadges(requireContext())
                                }
                        }
                    }
            } else {
                ref.child(key).setValue(expense)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Expense saved!", Toast.LENGTH_SHORT).show()
                        BadgeManager.checkAndAwardBadges(requireContext())
                    }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            photoUri = data?.data
        }
    }
}
