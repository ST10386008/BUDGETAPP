package com.example.budgettrackerapp.ui


import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.databinding.FragmentDashboardBinding
import com.example.budgettrackerapp.utils.BadgeManager

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)

        // 🏅 Check badges when dashboard loads
        BadgeManager.checkAndAwardBadges(requireContext())

        binding.btnAddExpense.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_addExpense)
        }

        binding.btnViewExpenses.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_viewExpenses)
        }

        binding.btnViewGraph.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_graph)
        }

        binding.btnCategories.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_addCategory)
        }

        binding.btnSetGoals.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_goal)
        }

        binding.btnToggleTheme.setOnClickListener {
            toggleTheme()
        }

        binding.btnBadges.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_badges)
        }

        return binding.root
    }

    private fun toggleTheme() {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        if (currentNightMode == Configuration.UI_MODE_NIGHT_YES) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}