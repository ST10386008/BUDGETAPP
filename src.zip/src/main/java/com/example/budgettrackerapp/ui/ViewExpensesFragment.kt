package com.example.budgettrackerapp.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.models.Expense
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ViewExpensesFragment : Fragment() {

    private lateinit var listView: ListView
    private val expenses = mutableListOf<Expense>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_view_expenses, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        listView = view.findViewById(R.id.expensesListView)
        adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, mutableListOf())
        listView.adapter = adapter

        loadExpenses()
    }

    private fun loadExpenses() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val ref = FirebaseDatabase.getInstance().getReference("users/$uid/expenses")

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                expenses.clear()
                adapter.clear()
                for (child in snapshot.children) {
                    val expense = child.getValue(Expense::class.java)
                    expense?.let {
                        expenses.add(it)
                        adapter.add("${it.description} (${it.amount})")
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to load expenses", Toast.LENGTH_SHORT).show()
            }
        })

        listView.setOnItemClickListener { _, _, position, _ ->
            val expense = expenses[position]
            if (expense.photoUrl.isNotEmpty()) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(expense.photoUrl))
                startActivity(intent)
            } else {
                Toast.makeText(context, "No photo attached", Toast.LENGTH_SHORT).show()
            }
        }
    }
}