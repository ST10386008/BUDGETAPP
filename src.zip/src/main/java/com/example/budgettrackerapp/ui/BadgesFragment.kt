package com.example.budgettrackerapp.ui

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.budgettrackerapp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class BadgesFragment : Fragment() {

    private lateinit var listView: ListView
    private val badgeList = mutableListOf<String>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_badges, container, false)
        listView = view.findViewById(R.id.badgeListView)
        loadBadges()
        return view
    }

    private fun loadBadges() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val ref = FirebaseDatabase.getInstance().getReference("users/$uid/badges")

        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                badgeList.clear()
                for (child in snapshot.children) {
                    if (child.getValue(Boolean::class.java) == true) {
                        badgeList.add(child.key ?: "")
                    }
                }
                listView.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, badgeList)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error loading badges", Toast.LENGTH_SHORT).show()
            }
        })
    }
}