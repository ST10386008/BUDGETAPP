package com.example.budgettrackerapp.utils

import android.content.Context
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

object BadgeManager {

    fun checkAndAwardBadges(context: Context) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val ref = FirebaseDatabase.getInstance().getReference("users/$uid")

        ref.child("expenses").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var totalSpent = 0.0
                val dates = mutableSetOf<String>()

                for (child in snapshot.children) {
                    val amount = child.child("amount").getValue(Double::class.java) ?: 0.0
                    val date = child.child("date").getValue(String::class.java) ?: ""
                    totalSpent += amount
                    if (date.isNotEmpty()) dates.add(date)
                }

                ref.child("goals").addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(goalSnap: DataSnapshot) {
                        val minGoal = goalSnap.child("min").getValue(Double::class.java) ?: 0.0
                        val maxGoal = goalSnap.child("max").getValue(Double::class.java) ?: Double.MAX_VALUE

                        if (totalSpent in minGoal..maxGoal) {
                            awardBadge(ref, "Budget Master", context)
                        }

                        if (dates.size >= 5) {
                            awardBadge(ref, "Consistent Logger", context)
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {}
                })
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun awardBadge(ref: DatabaseReference, badgeName: String, context: Context) {
        ref.child("badges").child(badgeName).setValue(true)
        Toast.makeText(context, "🏅 You earned the badge: $badgeName!", Toast.LENGTH_LONG).show()
    }
}